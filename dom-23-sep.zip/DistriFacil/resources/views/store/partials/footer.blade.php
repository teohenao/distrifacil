<footer class="container-fluid">
  <div class="row">
    <div class="col-md-4">
    
      <ul class="redes">
          <h3>Siguenos: </h3>
        <li>
          <a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
        </li>
        <li>
          <a href="#"><i class="fa fa-twitter-square fa-2x"></i></a>
        </li>
      </ul>
    
    </div>
  </div>
</footer>