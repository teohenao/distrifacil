<footer class="container-fluid text-center">
	<h3>time team<a href="#"></a></h3>
</footer>
